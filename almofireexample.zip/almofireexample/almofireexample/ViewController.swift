//
//  ViewController.swift
//  almofireexample
//
//  Created by MACOS on 5/2/17.
//  Copyright © 2017 MACOS. All rights reserved.
//

import UIKit
import Alamofire
class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let pramiter :Parameters = ["emp_name":"topstech","emp_add":"surattops","emp_mob":"1234567890"];
        Alamofire.request("http://localhost/test/index.php",method: .post, parameters: pramiter, encoding: URLEncoding.httpBody).responseString { response in
            print(response.request ?? "responce")  // original URL request
            print(response.response ?? "") // HTTP URL response
            print(response.data ?? "")     // server data
            print(response.result)
            
            print(response.error);
            
            // result of response serialization
            
            if let JSON = response.result.value {
                print("JSON: \(JSON)")
            }
        }
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

